#ifndef	_JIS_H_
#define	_JIS_H_

int ujtosj(char *to,int tosize,char *from);
int sjtouj(char *to,int tosize,char *from);

#endif
