#ifndef	_LOCK_F_
#define	_LOCK_F_

int LockFile(char *path);
int UnlockFile(int fd);

#endif
